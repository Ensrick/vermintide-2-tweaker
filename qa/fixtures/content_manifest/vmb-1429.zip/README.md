# VMB Launcher

A Windows GUI and headless build/deploy boundary for Vermintide 2 mods.
Workshop mutation is authorization-bound to a reviewed monorepo ship transaction.

![Workflow: Build, Deploy, Upload — one click each](https://img.shields.io/badge/platform-windows-blue) ![C#](https://img.shields.io/badge/.NET-9.0-512BD4) ![License](https://img.shields.io/badge/license-MIT-green)

## Download

Grab the latest `VMBLauncher.exe` from the [Releases page](https://github.com/Ensrick/vmb-launcher/releases). It's self-contained — no .NET install required.

> **Heads up:** the exe is unsigned, so on first launch Windows SmartScreen will say "Windows protected your PC". Click **More info** → **Run anyway**. Standard for any unsigned hobbyist tool.

## What it solves

The official VT2 modding workflow is several command-line tools chained together. There are footguns:

- Steam doesn't auto-subscribe you to your own Workshop uploads, so deploys silently fail until you manually subscribe.
- `vmb create` deletes your whole scaffold if the Workshop registration fails (Steam offline, missing SDK, etc).
- `ugc_tool` says "Upload finished" even when 0 bytes transferred.
- `bash -c "echo y | ..."` workarounds for the EULA prompt can trigger the Windows WSL installer if Git Bash isn't on PATH.

This tool handles all of that.

## What it does

- **Auto-detects** VMB, Steam, the VT2 SDK, `ugc_tool.exe`, and the Workshop content folder. Most users never touch the Settings dialog.
- **First-run setup** highlights anything missing with one-click fixes (auto-detect, browse, install SDK via Steam, subscribe in Steam).
- **Build / Deploy** buttons per mod. GUI publication actions explain the required reviewed ship workflow and never invoke `ugc_tool`.
- **Headless CLI** — same binary, run from PowerShell or cmd with verbs (`list`, `info`, `doctor`, `build`, `deploy`, `upload`, `all`). Real exit codes, streamed output, no second binary to install. See [Headless mode](#headless-mode) below.
- **Hash-verified deploys** so a half-flushed bundle never lands in the Workshop folder.
- **`--cwd` workflow supported** — projects with `.vmbrc` outside the VMB folder work without manual reconfiguration.
- **New-mod wizard** runs `vmb create` with pre-flight checks. If VMB deletes the scaffold after a failed Workshop registration, the wizard rebuilds the folder locally so nothing is lost.
- **Visibility-public guard** with explicit confirmation. Public mods that get reported are removed irreversibly; the tool makes you confirm every time.
- **Settings + Diagnostics** dialog for power users who want to override paths or just see what was detected.

## Headless mode

Any non-empty args (other than `--gui`) put the same binary into CLI mode:

```powershell
& .\VMBLauncher.exe list                              # list discovered mods
& .\VMBLauncher.exe info     my_mod                   # cfg + bundle state
& .\VMBLauncher.exe doctor                            # diagnostics
& .\VMBLauncher.exe build    my_mod [--clean]
& .\VMBLauncher.exe deploy   my_mod
& .\VMBLauncher.exe help                              # full reference
```

Workshop publication is driven only by the monorepo's
`tools\ship\ship.ps1`. Its exact order is: acquire the machine-global claim,
edit, run `ship.ps1 -BuildOnly`, commit source and bundles together, push/open
the PR, pass hosted `qa-gate`, merge, then run the canonical ship from clean
live default commit. The internal `upload`/`all` verbs require the exact receipt
hosted on the canonical GitHub release, valid for at most five minutes, and
independently reconstruct cfg, bundle, preview, and MOD_VERSION bytes from the
receipt-selected Git commit blobs before comparing the pinned SDK staging
snapshot. Local HEAD, index, and working-tree cleanliness are not byte
authority. A claim or hand-authored JSON alone cannot publish.

First Workshop item creation uses the same hosted-authorization path with the
distinct `workshop_bootstrap` receipt purpose. Every source blob and staged
input is proven exactly as above. Immediately before process creation, the
launcher releases only the staged cfg and its parent-directory lease so
`ugc_tool` can replace `published_id = 0L`; content files/directories, preview,
and executable remain pinned. After success, the complete staged cfg must differ
only by one nonzero
ID (plus ugc_tool's empty tags line), and source write-back is compare-and-swap
against the authorized Git blob. Duplicate source sentinels and IDs already
owned by another mod are rejected. The outer ship treats this as identity
bootstrap only: it does not mark issues test-ready and retains the machine-global
claim until the ID-only reconciliation is reviewed and merged.

For generated-output mods, an explicit `bundle_authority = receipt` receipt
additionally binds the committed inventory and ignore state, strict schema-3
build receipt, source-blob/build-byte map, complete normalized output map,
exact executing builder, and normalization policy. Bundle records carry path/length/SHA-256 but
no invented Git blob; the exact map must match the pinned SDK staging bytes.
Receipt-authority first-upload bootstrap remains disabled. Tracked hosted
receipts retain their exact legacy top-level contract and Git-commit-blob path.

VMBLauncher 0.6.2 also gives canonical ship a distinct, internal local-deploy
boundary: `deploy <mod> --no-remote --deployment-receipt <path>`. The launcher
independently authenticates the hosted schema-3 receipt, reconstructs its
commit-qualified exact output set and positive `published_id`, proves and pins
the matching `bundleV2` source bytes, and replaces exactly that one owned local
Workshop directory. Missing, empty, duplicate, caller-authored, or invalid
receipt authority fails before any new forward deployment and never falls
through to ordinary deploy. Before either receipt-authority or ordinary deploy,
the launcher first restores/finalizes an interrupted exact-set transaction for
that mod using only its durable journal, physical directory identities, and
recorded byte maps. Recovery therefore does not depend on a still-fresh receipt
or still-present project, mod, or source. The bounded two-slot checksummed
journal never replaces itself through an unowned temporary file. Unexpected
membership is preserved: before durable commit the replacement is quarantined
and the exact prior set is restored; after durable commit cleanup blocks for
explicit review. Re-authenticating the same short-lived receipt is an
idempotent replay of the same exact set; only each in-memory authorization
object is single-consume. This capability is local only: it does not authorize
remote exact-set deployment, updater installation, or a separate
updater/recovery consumer.
Ordinary direct `deploy` retains its copy behavior but cannot bypass an
outstanding receipt-authority recovery.

The publication and local-deploy guards have a strict two-repository landing
order: VMBLauncher **0.6.2 must be released and installed first**. Only then may
the monorepo receipt-authority local-deploy capability requirement land.
`ship.ps1` probes
`capabilities --no-banner` before any GitHub release mutation and fails closed
against older launchers or one without the machine transaction, crash-safe ACL
journal, exact-commit-blob, locked upload snapshot, and constrained first-upload
boundaries. Receipt-authority publication additionally requires
`receipt-authority-publication-v1`; receipt-authority local deploy separately
requires `receipt-authority-local-deploy-v1` and
`deployment_receipt_schema=3`.

All mutating launcher actions share
`Global\Ensrick.VMBLauncher.Transaction.v1`. The lease covers settings
auto-fill, build, parity checks, deploy, SDK staging, upload, Workshop
verification, and claim finalization. Direct GUI/CLI actions acquire it; an
immediate launcher child of canonical `ship.ps1` authenticates and joins the
parent’s lease. Do not run parallel VMB, launcher, or hand-written staging
commands around this boundary.

The transaction owner is placed in a named kill-on-close Windows Job before a
mutating child can spawn. A hard-death contender polls the exact persisted
Job's `ActiveProcesses` accounting, closes each temporary query handle
immediately, and proceeds only at zero or when the Job is absent. It does not
wait for ordinary Job signalling. A normal release authenticates and drains residual descendants
and deletes its authenticated owner record before unlocking. Every acquisition
recovers pre-existing durable authority even if the prior sole mutex handle
vanished and Windows recreated a fresh named object. Only the allowlisted canonical `%WINDIR%\explorer.exe`
shell boundary may explicitly break away for non-mutating Steam/browser/folder
UI. Settings paths are read-only until an authenticated transaction-owned save;
mutating CLI/GUI flows strictly reload after acquisition, reject an existing
unreadable/malformed config, and bind the lease to the exact resolved project
root actually used. Canonical `ship.ps1` never
rewrites shared settings and passes one durable exact-root private `--config`
to all launcher calls.

Upload ACL recovery is journaled and flushed before mutation and validates
SID/session/root/path/file identity plus exact descriptors. Never delete the
owner/ACL journal, manually reset staging ACLs, or parallel-retry around a
recovery failure.
Legacy recovery requires the exact launcher deny on both `sample_item` and
`content`, plus coherent parent/inheritance semantics for every deeper match.
Failed abandoned-owner recovery re-abandons without leaving a blocked owner
thread, so later contenders cannot normalize or bypass the failure.

Exit codes:

| Code | Meaning |
|------|---------|
| 0    | Success |
| 1    | Command failed at runtime |
| 2    | Bad usage — missing verb / mod / `--allow-public` on a public mod |
| 3    | Preflight failed — diagnostics blocked the action (run `doctor` to see why) |

Useful flags:

- `--no-banner` — suppress the version banner (good for piping)
- `--config <path>` — alternate settings file location
- `--gui` — force GUI even with other args present

Watch out for the **PowerShell pipeline-truncation quirk**: when you pipe through `Select-Object -First N`, PowerShell sets `$LASTEXITCODE = -1` regardless of the program's actual exit code. Capture into a variable before truncating:

```powershell
$lines = & .\VMBLauncher.exe list
$code  = $LASTEXITCODE     # this is the real exit code
$lines | Select-Object -First 5
```

For the full doctrine — when to use the headless CLI vs the legacy `.ps1` wrappers, preflight gates per verb, output streaming, broken-pipe behaviour — see [`CLAUDE.md`](./CLAUDE.md).

## Requirements

- Windows 10 or 11
- Steam, plus a Vermintide 2 license
- Vermintide Mod Builder ([github](https://github.com/Vermintide-Mod-Framework/Vermintide-Mod-Builder) — binary release recommended; Node-based clones also supported)
- Vermintide 2 SDK (install via Steam: Library → Tools → "Vermintide 2 SDK")

The launcher will tell you exactly which of these is missing on first launch and give you a button to fix it.

## Building from source

```powershell
git clone https://github.com/Ensrick/vmb-launcher.git
cd vmb-launcher
.\publish.ps1
```

`publish.ps1` runs the test suite, builds, and runs the headless smoke suite.
It opens no windows by default. Pass `-OpenOutput` only when you explicitly
want Explorer to select the resulting
`bin/Release/net9.0-windows/win-x64/publish/VMBLauncher.exe` (~60 MB).
If a launcher process holds that file, the default fails closed; only an
explicit human `-ForceStopLauncher` may terminate it.

For development:
```powershell
dotnet run -c Debug   # launch the GUI in debug mode
.\test.ps1            # run xUnit tests headlessly
```

### Tests

The xUnit suite covers the launcher service and command boundaries (run via
`test.ps1`). The downloader is fully tested with a mocked `HttpMessageHandler`,
so it never hits the live GitHub API in CI.

Plus an end-to-end **headless smoke suite** at `tests/headless_smoke.ps1` that
exercises the real binary against the real filesystem: every verb, every error
path, exit codes through cmd's pipe, truncated-pipe handling, and settings
auto-detect. It cannot launch GUI processes or execute `build`, `deploy`,
`upload`, or `all`, and runs automatically as part of `publish.ps1`. Every
invocation uses an isolated temporary settings copy and the suite proves the
real default settings bytes remain unchanged.

GUI routing and real local build/deploy integration have separate explicit
opt-in suites. They never run from `publish.ps1`, `test.ps1`, CI, or agent
verification:

```powershell
.\test.ps1                                      # unit tests
.\tests\headless_smoke.ps1                      # read-only Debug-binary checks
.\tests\gui_smoke.ps1 -Interactive              # visible windows; human only
.\tests\action_smoke.ps1 -IntegrationActions    # mutates local build/deploy state
```

`tests/check_noninteractive_contract.ps1` is the planted-failure guard that
keeps the default paths noninteractive.

## Settings file location

`%APPDATA%\VMBLauncher\settings.json`. Delete it to re-trigger the first-run setup flow.

## License

MIT — see [LICENSE](LICENSE).
