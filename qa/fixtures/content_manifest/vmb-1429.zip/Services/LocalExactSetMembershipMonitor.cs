using Microsoft.Win32.SafeHandles;
using System.IO;
using System.Runtime.InteropServices;

namespace VmbLauncher.Services;

/// <summary>
/// Kernel-backed target-membership arbitration for the final journal witness
/// transition. Cancellation is the commit linearization point: only a proven
/// ERROR_OPERATION_ABORTED for this exact OVERLAPPED request means cancel won
/// before any membership notification. Every other terminal state is treated
/// as changed/uncertain and retains the durable journal witness.
/// </summary>
internal static partial class LocalExactSetDeployment
{
    private enum MembershipArbitration
    {
        CancelWon,
        ChangedOrUncertain,
    }

    private sealed class DirectoryMembershipMonitor : IDisposable
    {
        private const uint FileNotifyChangeFileName = 0x00000001;
        private const uint FileNotifyChangeDirName = 0x00000002;
        private const uint FileFlagOverlapped = 0x40000000;
        private const int ErrorIoIncomplete = 996;
        private const int ErrorOperationAborted = 995;
        private const int ErrorNotFound = 1168;
        private const int BufferBytes = 64 * 1024;

        private SafeFileHandle? _directory;
        private SafeWaitHandle? _event;
        private IntPtr _buffer;
        private IntPtr _overlapped;
        private bool _terminal;

        private DirectoryMembershipMonitor() { }

        internal static DirectoryMembershipMonitor Arm(ExactDirectoryLease lease, string context)
        {
            lease.RequireCurrentPath(context);
            var monitor = new DirectoryMembershipMonitor();
            try
            {
                monitor._directory = CreateFileForMembershipMonitorW(
                    lease.CurrentPath,
                    FileListDirectory | FileReadAttributes,
                    FileShare.Read | FileShare.Write | FileShare.Delete,
                    IntPtr.Zero,
                    OpenExisting,
                    FileFlagBackupSemantics | FileFlagOpenReparsePoint | FileFlagOverlapped,
                    IntPtr.Zero);
                if (monitor._directory.IsInvalid)
                    throw new IOException(
                        $"Cannot arm target membership monitor (Win32 {Marshal.GetLastWin32Error()}).");
                var identity = IdentityFromHandle(monitor._directory, lease.CurrentPath);
                RequireIdentity(identity, lease.Identity, context);
                monitor._event = CreateEventW(
                    IntPtr.Zero,
                    manualReset: true,
                    initialState: false,
                    name: null);
                if (monitor._event.IsInvalid)
                    throw new IOException(
                        $"Cannot create target membership monitor event (Win32 {Marshal.GetLastWin32Error()}).");
                monitor._buffer = Marshal.AllocHGlobal(BufferBytes);
                monitor._overlapped = Marshal.AllocHGlobal(Marshal.SizeOf<NativeOverlappedState>());
                Marshal.StructureToPtr(new NativeOverlappedState
                {
                    EventHandle = monitor._event.DangerousGetHandle(),
                }, monitor._overlapped, fDeleteOld: false);
                if (!ReadDirectoryChangesW(
                        monitor._directory,
                        monitor._buffer,
                        BufferBytes,
                        watchSubtree: false,
                        FileNotifyChangeFileName | FileNotifyChangeDirName,
                        out _,
                        monitor._overlapped,
                        IntPtr.Zero))
                    throw new IOException(
                        $"Cannot arm target membership notification (Win32 {Marshal.GetLastWin32Error()}).");
                Checkpoint("membership-monitor-armed");
                return monitor;
            }
            catch
            {
                monitor.Dispose();
                throw;
            }
        }

        internal MembershipArbitration CancelAndArbitrate()
        {
            if (_terminal || _directory == null || _directory.IsInvalid || _overlapped == IntPtr.Zero)
                throw new InvalidOperationException("Target membership monitor is not armed.");

            var cancelReturned = CancelIoEx(_directory, _overlapped);
            var cancelError = cancelReturned ? 0 : Marshal.GetLastWin32Error();
            if (!cancelReturned && cancelError != ErrorNotFound)
            {
                // Force terminal completion for memory safety, but never turn
                // an unexpected cancellation result into commit authority.
                _directory.Dispose();
                WaitForTerminalEvent();
                _terminal = true;
                return MembershipArbitration.ChangedOrUncertain;
            }

            var completed = GetOverlappedResult(
                _directory,
                _overlapped,
                out _,
                wait: true);
            var completionError = completed ? 0 : Marshal.GetLastWin32Error();
            _terminal = true;
            Checkpoint("membership-monitor-terminal");

            // CancelIoEx returning true plus ERROR_OPERATION_ABORTED is the
            // only proof that cancellation won this exact request. If the
            // notification won, GetOverlappedResult succeeds. Overflow,
            // ERROR_NOT_FOUND races, and every ambiguous status fail closed.
            if (cancelReturned && !completed && completionError == ErrorOperationAborted)
            {
                Checkpoint("membership-monitor-cancel-won");
                return MembershipArbitration.CancelWon;
            }
            if (!completed && completionError == ErrorIoIncomplete)
                throw new IOException("Target membership monitor failed to reach terminal completion.");
            Checkpoint("membership-monitor-change-won");
            return MembershipArbitration.ChangedOrUncertain;
        }

        private void WaitForTerminalEvent()
        {
            if (_event == null || _event.IsInvalid) return;
            using var wait = new EventWaitHandle(false, EventResetMode.ManualReset);
            wait.SafeWaitHandle = new SafeWaitHandle(
                _event.DangerousGetHandle(),
                ownsHandle: false);
            if (!wait.WaitOne(TimeSpan.FromSeconds(5)))
                throw new IOException("Target membership monitor cancellation did not terminate.");
        }

        public void Dispose()
        {
            if (!_terminal && _directory is { IsInvalid: false } && _overlapped != IntPtr.Zero)
            {
                try { CancelIoEx(_directory, _overlapped); }
                catch { }
                try
                {
                    _ = GetOverlappedResult(_directory, _overlapped, out _, wait: true);
                }
                catch { }
                _terminal = true;
            }
            _directory?.Dispose();
            _directory = null;
            _event?.Dispose();
            _event = null;
            if (_overlapped != IntPtr.Zero)
            {
                Marshal.FreeHGlobal(_overlapped);
                _overlapped = IntPtr.Zero;
            }
            if (_buffer != IntPtr.Zero)
            {
                Marshal.FreeHGlobal(_buffer);
                _buffer = IntPtr.Zero;
            }
        }
    }

    [StructLayout(LayoutKind.Sequential)]
    private struct NativeOverlappedState
    {
        internal IntPtr Internal;
        internal IntPtr InternalHigh;
        internal uint Offset;
        internal uint OffsetHigh;
        internal IntPtr EventHandle;
    }

    [DllImport("kernel32.dll", CharSet = CharSet.Unicode, SetLastError = true,
        EntryPoint = "CreateFileW")]
    private static extern SafeFileHandle CreateFileForMembershipMonitorW(
        string fileName,
        uint desiredAccess,
        FileShare shareMode,
        IntPtr securityAttributes,
        uint creationDisposition,
        uint flagsAndAttributes,
        IntPtr templateFile);

    [DllImport("kernel32.dll", SetLastError = true)]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool ReadDirectoryChangesW(
        SafeFileHandle directory,
        IntPtr buffer,
        uint bufferLength,
        [MarshalAs(UnmanagedType.Bool)] bool watchSubtree,
        uint notifyFilter,
        out uint bytesReturned,
        IntPtr overlapped,
        IntPtr completionRoutine);

    [DllImport("kernel32.dll", SetLastError = true)]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool CancelIoEx(SafeFileHandle file, IntPtr overlapped);

    [DllImport("kernel32.dll", SetLastError = true)]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool GetOverlappedResult(
        SafeFileHandle file,
        IntPtr overlapped,
        out uint bytesTransferred,
        [MarshalAs(UnmanagedType.Bool)] bool wait);

    [DllImport("kernel32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
    private static extern SafeWaitHandle CreateEventW(
        IntPtr eventAttributes,
        [MarshalAs(UnmanagedType.Bool)] bool manualReset,
        [MarshalAs(UnmanagedType.Bool)] bool initialState,
        string? name);
}
