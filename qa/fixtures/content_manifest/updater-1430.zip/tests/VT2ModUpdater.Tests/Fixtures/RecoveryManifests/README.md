# Producer manifest fixtures

`producer-tracked-manifest.json` and `producer-receipt-manifest.json` are
byte-for-byte outputs of the complete schema-2 manifest producer at
vermintide-2-tweaker commit
`7e5732c77d6d9ad43f333f1fa5555e135fc9207e`.

The producer's offline `qa/check_release_recovery_record.ps1 -SelfTest` built
the tracked and receipt authority snapshots, deterministic ZIP coordinates,
and recovery children through `New-VtReleaseRecoveryRecord`. The fixture root
then used the same ordered fields, seven-fraction UTC publication timestamp,
and `ConvertTo-Json -Depth 12` plus UTF-8-without-BOM serialization as
`tools/publish-release/publish-release.ps1`. The complete producer self-test
passed while emitting both files.

The tests freeze the exact bytes with these SHA-256 values:

- tracked: `a6ab8c0fa0918c9b3f3514614012bdc543748dc43a6976ea77d95cf7773c7b46`
- receipt: `4bde52aba829acd435cef29ad55bf968d66add98cdb30670d7d83b13e997017c`

These are offline contract fixtures only. They do not authorize ZIP download,
installation, deployment, release mutation, or updater-path integration.
